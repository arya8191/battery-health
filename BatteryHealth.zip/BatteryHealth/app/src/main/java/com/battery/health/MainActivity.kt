package com.battery.health

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var design: EditText
    private var last: Intent? = null
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { last = i; render() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        out = TextView(this).apply { textSize = 16f; setLineSpacing(0f, 1.2f) }
        design = EditText(this).apply {
            hint = "Kapasitas desain (mAh), contoh: 5000"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getString("design", ""))
        }
        val btn = Button(this).apply { text = "Simpan & hitung ulang" }
        btn.setOnClickListener {
            prefs.edit().putString("design", design.text.toString().trim()).apply()
            render()
        }
        col.addView(out); col.addView(design); col.addView(btn)
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        last = if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(rx, f)
        render()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(rx) } catch (_: Exception) { }
    }

    private fun prop(bm: BatteryManager, id: Int): Int =
        try { bm.getIntProperty(id) } catch (_: Throwable) { Int.MIN_VALUE }

    // Kapasitas desain: input manual, atau coba baca dari sistem (tidak selalu bisa)
    private fun designCap(): Double? {
        prefs.getString("design", "")?.toDoubleOrNull()?.let { if (it > 0) return it }
        return try {
            val c = Class.forName("com.android.internal.os.PowerProfile")
            val o = c.getConstructor(Context::class.java).newInstance(this)
            (c.getMethod("getBatteryCapacity").invoke(o) as Double).takeIf { it > 0 }
        } catch (_: Throwable) { null }
    }

    private fun render() {
        val i = last ?: return
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = level * 100f / scale

        val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            2 -> "Baik"; 3 -> "Panas berlebih"; 4 -> "Rusak"
            5 -> "Tegangan berlebih"; 6 -> "Gagal"; 7 -> "Terlalu dingin"
            else -> "Tidak diketahui"
        }
        val status = when (i.getIntExtra(BatteryManager.EXTRA_STATUS, 1)) {
            2 -> "Mengisi"; 3 -> "Tidak mengisi (dipakai)"; 4 -> "Tidak mengisi"; 5 -> "Penuh"
            else -> "-"
        }
        val plug = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            1 -> "Charger AC"; 2 -> "USB"; 4 -> "Wireless"; else -> "-"
        }
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f
        val tech = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "-"
        val cycles = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1) // Android 14+
        val soh = prop(bm, 10) // STATE_OF_HEALTH, Android 14+ (kalau didukung HP)
        val cc = prop(bm, BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) // µAh
        val cur = prop(bm, BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) // µA

        val est = if (cc > 0 && pct >= 15f) cc / 1000.0 / (pct / 100.0) else null
        val des = designCap()
        val main = when {
            soh in 1..100 -> "$soh%  (data dari sistem)"
            est != null && des != null -> "~${minOf(100, (est / des * 100).toInt())}%  (estimasi)"
            else -> "belum bisa dihitung"
        }

        val sb = StringBuilder()
        sb.append("KESEHATAN BATERAI\n").append(main).append("\n\n")
        sb.append("Kondisi: $health\n")
        sb.append("Level: ${"%.0f".format(pct)}%  ($status, $plug)\n")
        sb.append("Suhu: ${"%.1f".format(temp)} °C\n")
        sb.append("Tegangan: ${"%.2f".format(volt)} V\n")
        if (cur != Int.MIN_VALUE) sb.append("Arus: ${Math.abs(cur) / 1000} mA\n")
        sb.append("Teknologi: $tech\n")
        sb.append("Siklus pengisian: ").append(if (cycles >= 0) "$cycles" else "tidak tersedia di HP ini").append("\n")
        if (est != null) sb.append("Kapasitas penuh (estimasi): ${est.toInt()} mAh\n")
        if (des != null) sb.append("Kapasitas desain: ${des.toInt()} mAh\n")
        if (soh !in 1..100 && (est == null || des == null)) {
            sb.append("\nIsi kapasitas desain (mAh) di bawah. Cek di kotak HP/spesifikasi.")
            if (est == null) sb.append(" Level baterai juga harus minimal 15%.")
            sb.append("\n")
        }
        sb.append("\nCatatan: kalau 'estimasi', angkanya kasar dan paling akurat saat baterai di atas 50%.")
        out.text = sb.toString()
    }
}
